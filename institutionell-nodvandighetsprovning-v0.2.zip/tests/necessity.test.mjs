import assert from 'node:assert/strict';
import test from 'node:test';
import { newDraft, exampleDraft, importDraft, toMarkdown, reviewWarnings } from '../src/lib/necessity/logic.mjs';

test('draft starts with two symmetrical alternatives', () => {
  const d = newDraft();
  assert.equal(d.version, 1);
  assert.equal(d.alternatives.length, 2);
  assert.ok(d.constraints.length >= 1);
});
test('import rejects unsupported versions and corrupt input', () => {
  assert.throws(() => importDraft('{what}'));
  assert.throws(() => importDraft({ version: 9 }));
  assert.throws(() => importDraft([]));
});
test('round-trip keeps content while normalizing unexpected fields', () => {
  const d = exampleDraft();
  const loaded = importDraft(JSON.stringify({ ...d, injected: 'ignored' }));
  assert.equal(loaded.statement, d.statement);
  assert.equal(loaded.alternatives.length, 2);
  assert.equal(loaded.injected, undefined);
  assert.equal(loaded.constraints[0].kind, 'capacity');
});
test('limited row count, enums, and input lengths', () => {
  const d = newDraft();
  d.statement = 'x'.repeat(20000);
  d.constraints = Array.from({length: 70}, () => ({ kind: 'forged', status: 'unverified', description: 'hi' }));
  d.alternatives = Array.from({length: 30}, () => ({name:'Test'}));
  const clean = importDraft(d);
  assert.equal(clean.statement.length, 6000);
  assert.equal(clean.constraints.length, 30);
  assert.equal(clean.constraints[0].kind, 'unknown');
  assert.equal(clean.alternatives.length, 12);
});
test('report does not hallucinate a recommendation and flags missing sources', () => {
  const d = newDraft();
  d.constraints[0].description = 'Juridiskt hinder';
  d.constraints[0].status = 'supported';
  const report = toMarkdown(d);
  assert.match(report, /Källa\/avsändare:\*\* Inte angivet/);
  assert.ok(reviewWarnings(d).some(x => x.includes('underbyggd utan källhänvisning')));
  assert.match(report, /Varken verktyget eller rapporten bedömer vilket alternativ som är bäst/);
});

test('English defaults, example, review prompts and full report are localized', () => {
  const blank = newDraft('en');
  assert.equal(blank.alternatives[0].name, 'Keep and improve the current system');
  const example = exampleDraft('en');
  assert.match(example.statement, /library open two additional evenings/);
  assert.equal(example.constraints[0].kind, 'capacity');
  assert.ok(reviewWarnings(newDraft('en'), 'en').some(x => x.includes('necessity claim')));
  const report = toMarkdown(example, 'en');
  assert.match(report, /^# Institutional Necessity Review/m);
  assert.match(report, /Evidence status: Not assessed/);
  assert.match(report, /Reversibility: High/);
  assert.doesNotMatch(report, /Inte angivet|Nödvändighet|Evidensstatus/);
});

test('English and Swedish export preserve the same authored data and JSON schema v1', () => {
  const draft = exampleDraft('sv');
  draft.statement = 'Custom claim / Eget påstående';
  const imported = importDraft(JSON.stringify(draft), 'en');
  assert.equal(imported.version, 1);
  assert.equal(imported.statement, draft.statement);
  assert.match(toMarkdown(imported, 'en'), /Custom claim \/ Eget påstående/);
  assert.match(toMarkdown(imported, 'sv'), /Custom claim \/ Eget påstående/);
  assert.match(toMarkdown(imported, 'en'), /## 4\. Courses of action/);
  assert.match(toMarkdown(imported, 'sv'), /## 4\. Handlingsalternativ/);
});
