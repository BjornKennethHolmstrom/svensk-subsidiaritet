# Institutionell nödvändighetsprövning / Institutional Necessity Review — v0.2

Den här versionen är **tvåspråkig (svenska/engelska)**. Den använder exakt samma globala språkstore som verktygssidan på Svensk Subsidiaritet:

```svelte
import { locale } from '$lib/stores/i18n';
```

När webbplatsens vanliga språkväxlare ändrar `$locale` uppdateras rubriker, formulär, hjälptexter, kategorier, granskningsvarningar, meddelanden, sidtitel, exempel vid ny inläsning och Markdown-export. Inget separat språkval behövs.

## Installera

1. Kopiera `src/lib/necessity/logic.mjs` och `src/lib/necessity/i18n.mjs` till `src/lib/necessity/` i webbplatsprojektet.
2. Kopiera `src/routes/verktyg/nodvandighetsprovning/+page.svelte` och `+page.js` till samma sökväg i projektet.
3. Om du redan installerat v0.1 ersätter dessa filer motsvarande tidigare filer. Utkast som sparats i localStorage eller exporterats som JSON (schema v1) kan fortfarande läsas.
4. Om du redan installerat kortet från det förra paketet behöver du **bara uppdatera engelska kortbeskrivningen** så att påståendet `Currently available in Swedish.` tas bort. Färdig `translations.ts` finns i `integration/`. Om kortet inte lagts in finns också `integration/verktyg-+page.svelte` som ersätter verktygssidan (`src/routes/verktyg/+page.svelte`). Lägg översättningsfilen på **samma sökväg som din befintliga `translations.ts`** (som inte kan fastställas från uppladdningen).
5. Kör `node --test tests/necessity.test.mjs`, `npm run dev` och sedan `npm run build` i ditt verkliga projekt.
6. Kontrollera `/verktyg/nodvandighetsprovning/` både när webbplatsen är inställd på `sv` och `en`, gärna även efter ett språkbyte mitt i formuläret.

## Vad som är översatt

- Sidans navigering, introduktion, alla fem steg, rubriker, frågor och platshållartexter.
- Kategorier för begränsningar, evidensstatus och reversibilitet (men persistenta JSON-enumvärden förblir oförändrade).
- Fiktivt biblioteksexempel när det väljs på respektive språk.
- Feedback, bekräftelsedialoger, integritetsinformation, import/export och granskningsvarningar.
- Rapporter i Markdown på valt språk, inklusive fältetiketter och ansvarsfriskrivningar.

**Viktigt:** Användarens befintliga innehåll översätts inte automatiskt. Byter du språk mitt i en analys finns skriven text kvar som den är; endast gränssnittet och rapportens fasta texter byter språk. Om du vill se exempelberättelsen på det nya språket får du välja ”Utforska fiktivt exempel” / ”Explore fictional example” igen (det ersätter utkastet efter bekräftelse). Defaultnamn i helt tomma utkast följer språkvalet.

## Datamodell och integritet

Schema v1, lokal sparning och JSON-import/export är oförändrade. `localStorage` har samma nyckel (`svensksubsidiaritet:necessity:v1`) som tidigare. Ingen backend eller AI-tjänst används; ingen automatisk faktagranskning eller politisk rekommendation sker. Verktyget bör inte användas för känsliga personuppgifter.

## Teststatus

- 7 automatiserade Node-tester av datahantering, svenska och engelska rapporter, backward compatibility och lokaliserade varningar.
- **Inte kompilerad mot ditt faktiska SvelteKit-projekt** eftersom källkoden för hela projektet inte finns i paketet och Svelte-kompilatorn inte är tillgänglig i den här miljön. Kör `npm run build` lokalt före publicering.

`exempel-bibliotek.md` och `example-library-en.md` innehåller referensrapporter från den nya koden.
