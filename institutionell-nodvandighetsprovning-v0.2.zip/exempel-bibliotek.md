# Institutionell nödvändighetsprövning

> Arbetsunderlag, inte juridisk rådgivning, faktagranskning eller policyrekommendation.
> Kategorisering är preliminär. Påståenden kräver extern prövning.

## 1. Påståendet

**Påstående:** ”Det går inte att hålla biblioteket öppet två kvällar till i veckan.”

**Källa/avsändare:** Hypotetiskt exempel – inte ett citat från någon kommun

**Sammanhang:** Fiktiv kommunal bibliotekssituation; enbart för att demonstrera metoden.

**Berörda:** Bibliotekets personal, barn och unga, kvällsbesökare, skattebetalare.

## 2. Identifierade begränsningar

### Personal behöver kunna bemanna två extra kvällar.

- Kategori: Kapacitet / resurser
- Evidensstatus: Ej prövad
- Underlag: Inte angivet
- Källa: Inte angivet
- Vem kan ändra detta: Biblioteksledning och kommun inom gällande regler
- Villkor för ändring: Pröva bemanningsalternativ och arbetsmiljökrav.

### Utökade öppettider kräver resurser i kommunens budget.

- Kategori: Finansiell / budget
- Evidensstatus: Ej prövad
- Underlag: Inte angivet
- Källa: Inte angivet
- Vem kan ändra detta: Kommunfullmäktige / berörd nämnd
- Villkor för ändring: Undersök faktiska merkostnader och omprioriteringar.

## 3. Nulägets funktion

**Vad fungerar:** Gällande öppettider passar nuvarande schemaläggning och lokalkostnader.

**Vad fungerar sämre:** De som inte kan besöka biblioteket dagtid får sämre tillgång.

**Om vi inte ändrar något:** Tillgänglighetsproblemet kvarstår, men inga nya kostnader uppstår.

**Starkaste argumentet för dagens ordning:** Befintliga anslag och personalens arbetsmiljö kan begränsa en utökning.

## 4. Handlingsalternativ

### 1. Behåll och förbättra nuläget

- Hur det fungerar: Behåll tiderna, förbättra digital tillgänglighet och information.
- Vad som bör bevaras: Befintlig bemanning och kostnadskontroll.
- Förutsättningar: Inte angivet
- Nackdelar / risker: Ingen direkt lösning för kvällsbesökare.
- Osäkerheter: Inte angivet
- Källor / erfarenheter: Inte angivet
- Beslutsmandat: Inte angivet
- Reversibilitet: Hög

### 2. Pröva en extra kväll

- Hur det fungerar: Tidsbegränsat test med en extra kväll snarare än två.
- Vad som bör bevaras: Bibliotekets samhällsuppdrag och personalens skyddsregler.
- Förutsättningar: Arbetsmiljöbedömning, bemanning, lokal budget och samråd.
- Nackdelar / risker: Kostnad, risk för förskjutet personalbehov och begränsad räckvidd.
- Osäkerheter: Efterfrågan och effekten på personalens arbetsbelastning.
- Källor / erfarenheter: Inte angivet
- Beslutsmandat: Beslut inom kommunens befogenheter; behöver kontrolleras.
- Reversibilitet: Hög

## 5. Lärande / möjlig prövning

**Lärandefråga:** Ökar en extra kväll den faktiska tillgängligheten utan oacceptabel arbetsbelastning?

**Metod:** Frivilligt, tidsbegränsat försök efter samråd med berörda.

**Uppföljning:** Besökare per timme, upplevd tillgänglighet, personalens arbetsmiljö och total merkostnad.

**Skyddsräcken:** Följ arbetsrätt och arbetsmiljökrav; inga förändringar utan berördas medverkan.

**Avbrytningskriterier:** Avbryt vid arbetsmiljörisker eller om beslutade kostnadsramar överskrids.

**Vilka deltar:** Personal, biblioteksanvändare inklusive grupper med svag tillgång.

**Mandat:** Ansvarig nämnd och förvaltning måste klarlägga mandat.

**Tidshorisont:** Exempel: 8–12 veckor (kräver lokalt beslut).

**Hur resultaten kan tolkas:** Ett positivt resultat stödjer ett lokalt försök, inte ett allmänt bevis för andra kommuner.

## 6. Saker som behöver kontrolleras

- Inga automatiska påminnelser. Detta är inte en verifiering.

---

Skapat med Institutionell nödvändighetsprövning (schema v1), Svensk Subsidiaritet.
Varken verktyget eller rapporten bedömer vilket alternativ som är bäst.