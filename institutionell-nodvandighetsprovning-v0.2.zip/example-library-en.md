# Institutional Necessity Review

> Working notes, not legal advice, fact-checking or a policy recommendation.
> Categories are provisional. Claims require independent verification.

## 1. The claim

**Claim:** “It is not possible to keep the library open two additional evenings each week.”

**Source / speaker:** Hypothetical example – not a quotation from any municipality

**Context:** Fictional municipal library scenario, used only to demonstrate the method.

**Affected groups:** Library staff, children and young people, evening visitors and taxpayers.

## 2. Identified constraints

### Staff must be available for two additional evenings.

- Category: Capacity / resources
- Evidence status: Not assessed
- Evidence: Not specified
- Source: Not specified
- Who can change this: Library management and municipality, within current rules
- Conditions for change: Examine staffing options and workplace safety requirements.

### Extended hours require resources in the municipal budget.

- Category: Financial / budgetary
- Evidence status: Not assessed
- Evidence: Not specified
- Source: Not specified
- Who can change this: Municipal council / relevant committee
- Conditions for change: Examine actual incremental costs and reallocations.

## 3. Functions of the current system

**What works:** Current opening hours match existing staff schedules and premises costs.

**What works less well:** People who cannot visit during the day have poorer access.

**If nothing changes:** The access problem remains, but no additional costs arise.

**Strongest case for the present system:** Existing funding and staff working conditions may limit extended hours.

## 4. Courses of action

### 1. Keep and improve the current system

- How it works: Keep current hours but improve digital access and information.
- What should be preserved: Current staffing and cost control.
- Requirements: Not specified
- Drawbacks / risks: No direct solution for evening visitors.
- Uncertainties: Not specified
- Sources / experience: Not specified
- Decision-making authority: Not specified
- Reversibility: High

### 2. Try one extra evening

- How it works: Time-limited test of one extra evening instead of two.
- What should be preserved: The public library mission and worker protections.
- Requirements: Work environment assessment, staffing, local budget and consultation.
- Drawbacks / risks: Costs, risk of shifted staffing needs and limited reach.
- Uncertainties: Demand and impact on staff workload.
- Sources / experience: Not specified
- Decision-making authority: Decision within municipal powers; needs verification.
- Reversibility: High

## 5. Learning / possible trial

**Learning question:** Does one extra evening improve actual access without unacceptable staff workload?

**Method:** Voluntary, time-limited trial after consulting those affected.

**Monitoring:** Visitors per hour, perceived access, staff working conditions and total extra costs.

**Safeguards:** Follow labor and workplace safety rules; no change without those affected having a say.

**Stopping criteria:** Stop if working conditions become unsafe or approved spending limits are exceeded.

**Who participates:** Staff and library users, including groups with limited access.

**Authority:** The responsible committee and administration must clarify authority.

**Time horizon:** For example, 8–12 weeks (requires a local decision).

**How the results can be interpreted:** A positive result supports a local trial; it is not general proof for other municipalities.

## 6. Matters to check

- No automatic prompts. This is not verification.

---

Created with Institutional Necessity Review (schema v1), Svensk Subsidiaritet.
Neither the tool nor the report determines which alternative is best.