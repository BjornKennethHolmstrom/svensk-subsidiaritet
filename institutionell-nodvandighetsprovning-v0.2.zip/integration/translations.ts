export const translations = {
  sv: {
    nav: {
      vision: "Vision",
      architecture: "Arkitektur",
      frameworks: "Ramverk",
      resources: "Resurser",
      analysis: "Systemanalys",
      tools: "Verktyg",
      library: "Bibliotek",
      about: "Om"
    },
    header: {
      subtitle: "Forskning och policy för adaptiv och distribuerad styrning"
    },
    footer: {
      rights: "Eget innehåll · CC BY 4.0",
      built_with: "Svensk Subsidiaritet är ett svenskt forsknings- och policyprojekt inom styrning. Det bygger på Styrning som ingenjörskonst och utvecklar svenska tillämpningar av idéer som är kompatibla med Global Governance Frameworks.",
      contact: "Kontakt"
    },
    architecture: {
      navLabel: "Arkitektur",
      shortLabel: "Styrningsarkitektur",
      pages: {
        spektrum: "Styrningsspektrumet",
        matris: "Arkitekturmatrisen",
        "adaptivSubsidiaritet": "Adaptiv subsidiaritet",
        "polycentriskStyrning": "Polycentrisk styrning",
        "metaStyrning": "Meta-styrning"
      }
    },
    transition: {
      navLabel: "Övergången",
      shortLabel: "Övergången",
      pages: {
        overgangsgraf: "Övergångsgrafen",
        overgangsdalen: "Övergångsdalen",
        broinstitutioner: "Broinstitutioner",
        reformvag: "Svensk reformväg"
      }
    },
    evidence: {
      navLabel: "Evidens",
      sections: {
        howWeKnow: "Så vet vi",
        research: "Forskning",
        cases: "Fall",
        dataModels: "Data & modeller",
        synthesis: "Syntes"
      },
      labels: {
        overview: "Evidens",
        howWeKnow: "Så vet vi",
        questions: "Våra frågor",
        evidenceStandards: "Evidensstandarder",
        gaeLens: "GAE som analytisk lins",
        research: "Forskning",
        r1: "Subsidiaritet & decentralisering",
        r2: "Skala, kapacitet & specialisering",
        r3: "Spridningseffekter & flernivåstyrning",
        r4: "Polycentrisk styrning",
        r5: "Demokratisk närhet & deltagande",
        r6: "Offentlig finansiering & utjämning",
        r7: "Samordning, komplexitet & ansvar",
        r8: "Medborgarkapacitet & styrning",
        r9: "Styrning & anpassning",
        cases: "Fall",
        s1: "Kommunsammanslagningar (S1)",
        s2: "Skoldecentralisering (S2)",
        s3: "Ädelreformen (S3)",
        s4: "Kommunalekonomisk utjämning (S4)",
        s5: "Mellankommunal samverkan (S5)",
        s6: "Räddningstjänsten (S6)",
        dataModels: "Data & modeller",
        matt: "Mått",
        beslutsnarhet: "Beslutsnärhet",
        auktoritetsdjup: "Auktoritetsdjup",
        modeller: "GAE-modeller",
        nodvandigVariation: "Nödvändig variation (GAE IV)",
        samordningsskatt: "Samordningsskatt (GAE V)",
        adaptationsflaskhalsen: "Adaptationsflaskhalsen (GAE XV)",
        simuleringar: "Simuleringar",
        aubi: "AUBI-simuleringar",
        styrningsfaktorisering: "Kan styrningens skala faktoriseras?",
        synthesis: "Syntes",
        matrix: "Evidensmatrisen",
        whatWeKnow: "Vad vi vet",
        counterevidence: "Motevidens",
        unknowns: "Vad vi inte vet",
        openQuestions: "Öppna frågor"
      }
    },
    systemAnalysis: {
      food: "Livsmedelssystem",
      healthcare: "Hälsovård",
      education: "Utbildning",
      elderCare: "Äldreomsorg",
      housing: "Boende",
      energy: "Energi",
      transport: "Transport",
      welfare: "Välfärd",
      safety: "Trygghet och säkerhet",
      culture: "Kultur och medier",
      // Upcoming systems
      water: "Vattenförvaltning",
      waste: "Avfall och cirkulär ekonomi",
      finance: "Finansiella system",
      legal: "Rättssystem",
      childcare: "Barnomsorg",
      land: "Markanvändning",
      immigration: "Immigration och integration",
      research: "Forskning och innovation"
    },
    frameworks: {
      title: "Ramverk",
      subtitle: "De idéer, mätverktyg och forskningsprogram som hjälper oss att förstå, mäta och utveckla styrning för ett komplext samhälle.",
      gsi: {
        title: "Global Subsidiarity Index (GSI)",
        description: "Ett universellt mätverktyg för styrningsarkitektur. Mäter beslutsavstånd, kunskapsinkludering och resiliensarkitektur i nationer, regioner och kommuner.",
        action: "Utforska ramverket"
      },
      aubi: {
        title: "Adaptiv universell basinkomst (AUBI)",
        description: "Subsidiarity kräver kognitiv bandbredd. AUBI är den ekonomiska infrastruktur som frigör medborgarnas kapacitet att faktiskt delta i distribuerad styrning.",
        action: "Läs analysen"
      },
      governanceEngineering: {
        title: "Governance as Engineering",
        description: "Ett forskningsprogram som tillämpar systemteori, styrteori, cybernetik och empirisk testning på styrning av komplexa adaptiva system.",
        action: "Läs forskningsguiden"
      },
      ggf: {
        title: "Global Governance Frameworks",
        description: "Ett globalt ramverk för samordnad, subsidiär och adaptiv styrning över nivåer, domäner, kulturer och tidsskalor.",
        action: "Besök GGF"
      },
      relationship: {
        title: "Hur hänger de ihop?",
        hardware: "Subsidiaritet är hårdvaran",
        electricity: "AUBI är strömmen",
        explanation: "GSI mäter om styrningsarkitekturen matchar samhällets komplexitet. Men distribuerad styrning kräver medborgare med tid, trygghet och kognitiv kapacitet att delta. AUBI är det ekonomiska ramverk som möjliggör detta."
      }
    },
    simulatorPage: {
      title: "Systemsimulator för styrningsstabilitet",
      subtitle: "En styrteoretisk modell för institutionell anpassning",
      basedOn: "Baserat på artiklarna:",
      papers: {
        p1: "I: Styrning som ett återkopplingssystem",
        p2: "II: Fraktalitet som stabilitet",
        p3: "III: Sambandet mellan observerbarhet och demokrati",
        p4: "IV: Nödvändig mångfald och allmänningen",
        p5: "V: Koordineringsskatten"
      },
      explanation: {
        title: "Vad du ser",
        centralized: "<strong>Centraliserad</strong> (Artikel I): En central styrenhet observerar det nationella genomsnittet och tillämpar en enhetlig policy. Hög latens och aggregering förstör rumslig information. Sidoskador sprider sig.",
        local: "<strong>Endast lokal</strong> (Artikel II): Varje nod reagerar på sitt eget tillstånd. Snabba chocker hanteras, men en långsam trend skapar ihållande svängningar.",
        fractal: "<strong>Fraktal / polycentrisk</strong> (Artikel II & V): Kapslade lokala, regionala och globala styrenheter täcker alla störningsfrekvenser. Koordineringsskatten minimeras."
      },
      quote: "\"Bara mångfald kan absorbera mångfald.\" — Ross Ashby, Law of Requisite Variety (1956)"
    },
    simulatorData: {
      controls: {
        architecture: "Styrningsarkitektur",
        centralized: "Centraliserad",
        localOnly: "Endast lokal",
        fractal: "Fraktal / polycentrisk",
        complexity: "Miljöns komplexitet",
        disturbanceMix: "Störningsmix",
        lowVariety: "Låg variation",
        highVariety: "Hög variation",
        slowDrift: "Långsam trend",
        fastShocks: "Snabba chocker",
        reset: "Återställ simulering",
        tooltip1: "Artikel I och II: Centraliserad förstör spatial information. Fraktal täcker alla frekvensband.",
        tooltip2: "Ashbys lag: Miljöer med högre variation kräver mer styrningsvariation för att stabiliseras.",
        tooltip3: "Artikel II: Snabba chocker kräver låg latens; långsam drift kräver långa observationsfönster."
      },
      metrics: {
        stability: "Systemets stabilitet",
        variety: "Nödvändig mångfald",
        coverage: "Frekvenstäckning",
        tax: "Koordineringsskatt",
        catastrophic: "Katastrofal skatt",
        moderate: "Måttlig skatt",
        unobservable: "OOBSERVERBAR"
      },
      plot: {
        title: "Varians i realtid",
        target: "Måljämvikt"
      },
      regions: ["Kust i norr", "Skogsdistrikt", "Stadskärna", "Jordbruksslätt", "Fjäll i söder"],
      layers: {
        central: "CENTRAL",
        local: "LOKAL",
        region: "REGION"
      }
    },
    tools: {
      title: "Verktygslådan",
      subtitle: "Från analys till handling: interaktiva verktyg och utbildningsmaterial.",
      compass: {
        title: "Närhetskompassen",
        description: "Ett interaktivt diagnosverktyg för att mäta maktavstånd, kunskapsinkludering och resiliens i din organisation eller kommun.",
        action: "Starta Diagnos"
      },
      workshop: {
        title: "Studiecirkel-Kit",
        description: "Komplett material för att leda en studiecirkel om subsidiaritet i din förening eller ditt grannskap.",
        action: "Utforska, ladda ner och skriv ut"
      },
      necessity: {
        title: "Institutionell nödvändighetsprövning",
        description: "Undersök påståenden om vad som måste vara på ett visst sätt. Skilj faktiska begränsningar från institutionella val, utforska alternativ och formulera lärande experiment.",
        action: "Pröva ett påstående"
      },
      power: {
        title: "Maktanalys",
        description: "Kartlägg var makten faktiskt sitter — vem bestämmer, vem kontrollerar budgeten, hur långt borta?",
        action: "Kartlägg Makten"
      },
      simulator: {
        title: "Systemsimulator",
        description: "En interaktiv modell som bevisar varför centraliserade system misslyckas med att hantera lokal komplexitet. Lek med matematiken bakom subsidiaritet.",
        action: "Testa Simulatorn"
      },
      school: {
        title: "För Skolan",
        description: "Färdiga lektionsplaneringar och moduler för gymnasiet. Bygg systemförståelse i klassrummet.",
        action: "Gå till Lärarrummet"
      },
      ngo_pledge: {
        title: "NGO‑löfte",
        description: "Ett verktyg för att flytta makt och resurser från internationella huvudkontor till lokalsamhällen. Fem konkreta åtaganden för hjälporganisationer.",
        action: "Läs löftet"
      },
      library: {
        title: "Mönsterbiblioteket",
        description: "En databas över beprövade lösningar för decentralisering, från matgillen till energigemenskaper.",
        action: "Utforska (Snart)"
      }
    },
    contact: {
      title: "Kontakt",
      subtitle: "Vi bygger detta tillsammans. Har du idéer, kritik eller vill du bidra?",
      email_label: "Föredrar du e-post?",
      form: {
        name: "Namn",
        email: "E-post",
        topic: "Vad gäller det?",
        message: "Meddelande",
        submit: "Skicka Meddelande",
        success: "Tack! Vi återkommer så snart vi kan."
      },
      topics: {
        general: "Allmän fråga",
        tools: "Feedback på Verktyg / Kompassen",
        site: "Förslag till webbplatsen",
        collab: "Samarbete / Starta Studiecirkel",
        press: "Press / Media"
      }
    }
  },
  en: {
    nav: {
      vision: "Vision",
      architecture: "Architecture",
      frameworks: "Frameworks",
      resources: "Resources",
      analysis: "System Analysis",
      tools: "Tools",
      library: "Library",
      about: "About"
    },
    header: {
      subtitle: "Research and policy for adaptive and distributed governance "
    },
    footer: {
      rights: "Original content · CC BY 4.0",
      built_with: "Svensk Subsidiaritet is a Swedish governance research and policy project. It draws on Governance as Engineering and develops Swedish applications of ideas compatible with the Global Governance Frameworks.",
      contact: "Contact"
    },
    architecture: {
      navLabel: "Architecture",
      shortLabel: "Governance Architecture",
      pages: {
        spektrum: "The Governance Spectrum",
        matris: "The Governance Architecture Matrix",
        "adaptivSubsidiaritet": "Adaptive Subsidiarity",
        "polycentriskStyrning": "Polycentric Governance",
        "metaStyrning": "Meta-Governance"
      }
    },
    transition: {
      navLabel: "Transition",
      shortLabel: "Transition",
      pages: {
        overgangsgraf: "The Transition Graph",
        overgangsdalen: "The Transition Valley",
        broinstitutioner: "Bridge Institutions",
        reformvag: "Swedish Reform Path"
      }
    },
    evidence: {
      navLabel: "Evidence",
      sections: {
        howWeKnow: "How We Know",
        research: "Research",
        cases: "Cases",
        dataModels: "Data & Models",
        synthesis: "Synthesis"
      },
      labels: {
        overview: "Evidence",
        howWeKnow: "How We Know",
        questions: "Our Questions",
        evidenceStandards: "Evidence Standards",
        gaeLens: "GAE as an Analytical Lens",
        research: "Research",
        r1: "Subsidiarity & Decentralization",
        r2: "Scale, Capacity & Specialization",
        r3: "Spillovers & Multilevel Governance",
        r4: "Polycentric Governance",
        r5: "Democratic Proximity & Participation",
        r6: "Public Finance & Equalization",
        r7: "Coordination, Complexity & Accountability",
        r8: "Civic Capability & Governance",
        r9: "Governance & Adaptation",
        cases: "Cases",
        s1: "Municipal Mergers (S1)",
        s2: "School Decentralization (S2)",
        s3: "Ädelreformen (S3)",
        s4: "Fiscal Equalization (S4)",
        s5: "Intermunicipal Cooperation (S5)",
        s6: "Rescue Service (S6)",
        dataModels: "Data & Models",
        matt: "Measures",
        beslutsnarhet: "Decision Proximity",
        auktoritetsdjup: "Authority Depth",
        modeller: "GAE Models",
        nodvandigVariation: "Requisite Variety (GAE IV)",
        samordningsskatt: "Coordination Tax (GAE V)",
        adaptationsflaskhalsen: "The Adaptation Bottleneck (GAE XV)",
        simuleringar: "Simulations",
        aubi: "AUBI Simulations",
        styrningsfaktorisering: "Can Governance Scale Be Factorized?", 
        synthesis: "Synthesis",
        matrix: "Evidence Matrix",
        whatWeKnow: "What We Know",
        counterevidence: "Counterevidence",
        unknowns: "What We Don't Know",
        openQuestions: "Open Questions"
      }
    },
    systemAnalysis: {
      food: "Food Systems",
      healthcare: "Healthcare",
      education: "Education",
      elderCare: "Elder Care",
      housing: "Housing",
      energy: "Energy",
      transport: "Transport",
      welfare: "Welfare",
      safety: "Safety and Policing",
      culture: "Culture and Media",
      // Upcoming systems
      water: "Water Management",
      waste: "Waste & Circular Economy",
      finance: "Financial Systems",
      legal: "Legal System",
      childcare: "Childcare & Family Policy",
      land: "Land Use & Natural Resources",
      immigration: "Immigration & Integration",
      research: "Research & Innovation"
    },
    frameworks: {
      title: "Frameworks",
      subtitle: "The ideas, measurement tools and research programs that help us understand, measure and develop governance for a complex society.",
      gsi: {
        title: "Global Subsidiarity Index (GSI)",
        description: "A universal measurement tool for governance architecture. Measures decision distance, knowledge inclusion, and resilience architecture across nations, regions, and municipalities.",
        action: "Explore the framework"
      },
      aubi: {
        title: "Adaptive Universal Basic Income (AUBI)",
        description: "Subsidiarity requires cognitive bandwidth. AUBI is the economic infrastructure that unlocks citizens' capacity to actually participate in distributed governance.",
        action: "Read the analysis"
      },
      governanceEngineering: {
        title: "Governance as Engineering",
        description: "A research programme applying systems theory, control theory, cybernetics, and empirical testing to governing complex adaptive systems.",
        action: "Read the research guide"
      },
      ggf: {
        title: "Global Governance Frameworks",
        description: "A global framework for coordinated, subsidiarity-based, and adaptive governance across levels, domains, cultures, and timescales.",
        action: "Visit GGF"
      },
      relationship: {
        title: "How do they connect?",
        hardware: "Subsidiarity is the hardware",
        electricity: "AUBI is the electricity",
        explanation: "The GSI measures whether governance architecture matches societal complexity. But distributed governance requires citizens with the time, security, and cognitive capacity to participate. AUBI is the economic framework that makes this possible."
      }
    },
    simulatorPage: {
      title: "Governance Stability Simulator",
      subtitle: "A control-theoretic model of institutional adaptation",
      basedOn: "Based on papers:",
      papers: {
        p1: "I: Governance as a Feedback System",
        p2: "II: Fractality as Stability",
        p3: "III: The Observability-Democracy Connection",
        p4: "IV: Requisite Variety and the Commons",
        p5: "V: The Coordination Failure Tax"
      },
      explanation: {
        title: "What you're seeing",
        centralized: "<strong>Centralized</strong> (Paper I): One controller observes the national average and applies uniform policy. High latency and aggregation destroy spatial information. Collateral disruption spreads.",
        local: "<strong>Local Only</strong> (Paper II): Each node responds to its own state. Fast shocks are handled, but slow drift produces persistent oscillation.",
        fractal: "<strong>Fractal / Polycentric</strong> (Papers II & V): Nested local, regional, and global controllers cover all disturbance frequencies. The coordination failure tax is minimized."
      },
      quote: "\"Only variety can absorb variety.\" — Ross Ashby, Law of Requisite Variety (1956)"
    },
    simulatorData: {
      controls: {
        architecture: "Governance Architecture",
        centralized: "Centralized",
        localOnly: "Local Only",
        fractal: "Fractal / Polycentric",
        complexity: "Environmental Complexity",
        disturbanceMix: "Disturbance Mix",
        lowVariety: "Low Variety",
        highVariety: "High Variety",
        slowDrift: "Slow Drift",
        fastShocks: "Fast Shocks",
        reset: "Reset Simulation",
        tooltip1: "Paper I & II: Centralized destroys spatial information. Fractal covers all frequency bands.",
        tooltip2: "Ashby's Law: Higher variety environments require more governance variety to stabilize.",
        tooltip3: "Paper II: Fast shocks require low latency; slow drift requires long observation windows."
      },
      metrics: {
        stability: "System Stability",
        variety: "Requisite Variety",
        coverage: "Freq. Coverage",
        tax: "Coordination Tax",
        catastrophic: "Catastrophic Tax",
        moderate: "Moderate Tax",
        unobservable: "UNOBSERVABLE"
      },
      plot: {
        title: "Real-Time Variance",
        target: "Target Equilibrium"
      },
      regions: ["Coastal North", "Forest District", "Urban Core", "Agri Plain", "Mountain South"],
      layers: {
        central: "CENTRAL",
        local: "LOCAL",
        region: "REGION"
      }
    },
    tools: {
      title: "The Toolkit",
      subtitle: "From analysis to action: interactive tools and educational materials.",
      compass: {
        title: "The Proximity Compass",
        description: "An interactive diagnostic tool to measure power distance, knowledge inclusion, and resilience in your organization or municipality.",
        action: "Start Diagnosis"
      },
      workshop: {
        title: "Study Circle Kit",
        description: "Complete materials for leading a study circle on subsidiarity in your association or neighborhood.",
        action: "Explore, Download and Print"
      },
      simulator: {
        title: "Systems Simulator",
        description: "An interactive model proving why centralized systems fail to handle local complexity. Play with the cybernetic math behind subsidiarity.",
        action: "Try the Simulator"
      },
      necessity: {
        title: "Institutional Necessity Review",
        description: "Examine claims about what must be a certain way. Distinguish material constraints from institutional choices, explore alternatives, and propose learning experiments.",
        action: "Examine an assumption"
      },
      power: {
        title: "Power Analysis",
        description: "Map where power actually resides — who decides, who controls the budget, how far away?",
        action: "Map Power"
      },
      school: {
        title: "For Schools",
        description: "Ready-made lesson plans and modules for high schools. Build systems thinking in the classroom.",
        action: "Enter Teacher's Lounge"
      },
      ngo_pledge: {
        title: "NGO Pledge",
        description: "A tool to shift power and resources from global headquarters to local communities. Five concrete commitments for aid organizations.",
        action: "Read the Pledge"
      },
      library: {
        title: "Pattern Library",
        description: "A database of proven decentralization solutions, from food guilds to energy communities.",
        action: "Explore (Coming Soon)"
      }
    },
    contact: {
      title: "Contact",
      subtitle: "We are building this together. Do you have ideas, critiques, or want to contribute?",
      email_label: "Prefer email?",
      form: {
        name: "Name",
        email: "Email",
        topic: "Topic",
        message: "Message",
        submit: "Send Message",
        success: "Thanks! We will get back to you soon."
      },
      topics: {
        general: "General Inquiry",
        tools: "Feedback on Tools / Compass",
        site: "Website Suggestions",
        collab: "Collaboration / Start Study Circle",
        press: "Press / Media"
      }
    }
  }
};
